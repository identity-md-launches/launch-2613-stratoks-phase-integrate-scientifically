# Recovery candidate — not yet published

See [current recovery results and blockers](docs/recovery/VALIDATION.md). The following worker handoff contains historical claims; its missing artifacts are not proof of validation.

# Stratoks · Phase 1.1

A working isometric browser client for the existing persistent Stratoks simulation. The client observes a single authoritative world over HTTPS/WSS, with creature inspection, population/resource history, wallet-authenticated visits and developer interventions. A clearly labeled private demo runs the **same simulation engine** in a Web Worker.

Phase 1.1 integrates the repaired service with the existing client. [Current validation and finding-to-fix table](docs/recovery/VALIDATION.md) records this revision's tests, recovery/migration guidance and publication blockers. The corrected static export is in `dist/`. Public publication has **not** been verified: the previous ENS gateway returns `ERR_SSL_PROTOCOL_ERROR`, and this task cannot use the operator's machine identity to publish. Final release URL, CID and Git commit are pending IMD capture/publication; the old CID is not this release.

**No server is configured in the delivered export.** The first screen says “World server not connected” and displays only labeled illustrative terrain. Choose **Explore local demo** to run a private simulation; this never impersonates the shared world.

![Actual running prototype, local demo](docs/screenshots/demo-desktop.png)

## Run the delivered site

Use Node.js 24 (the checks used v24.21.0). The committed `dist/` is complete and can be previewed without installing anything:

```sh
node web/scripts/preview.mjs
```

Open `http://127.0.0.1:4173/preview/`. The `/preview/` subpath deliberately checks relative assets. Stop with Ctrl+C. Do not open `index.html` directly as a `file:` URL; module workers require an HTTP(S) origin.

## Install, typecheck and rebuild

```sh
node web/scripts/task.mjs install
node web/scripts/task.mjs typecheck
node web/scripts/task.mjs test
node web/scripts/task.mjs build
```

The helper copies the frontend and its existing engine dependencies to an isolated directory under the OS temporary directory, installs from `web/package-lock.json`, and copies the production export back to **repository-root `dist/`**. Dependencies and caches never enter the repository. `node web/scripts/task.mjs path` prints that isolated frontend directory for diagnostic tools. The ordinary package scripts are also in `web/package.json`.

Stack: React 19, TypeScript, Vite 8, native Canvas 2D and Web Workers; wagmi, viem and React Query for signature-only accounts. Vite uses `base: './'`. The static site needs no server-rendered routes. Fonts and artwork are bundled locally. There are no tokens, NFTs, contracts, pools or payments in this phase.

## Connect the real simulation

For local integration, run the existing service in a second terminal:

```sh
DEMO_MODE=1 DATA_DIR=/tmp/stratoks-local-world node server/src/main.js
```

In the client, open **Settings**, enter `http://localhost:8787` as the service URL, leave the WebSocket field blank, and choose **Connect to world**. The client derives `ws://localhost:8787/ws`. This is labeled **Local test server**. Restarting that service with the same data directory preserves the world and learned state. Unlike the private browser demo, it continues with no browsers connected.

Production requires the owner’s actual HTTPS and WSS endpoints. Enter them in Settings, or populate `web/public/world-config.json` and rebuild. Its intentionally empty defaults are:

```json
{ "httpUrl": "", "wsUrl": "" }
```

Saved browser settings override this file. **Disconnect and clear saved settings** removes that override. HTTPS pages require HTTPS/WSS; HTTP/WS is restricted to localhost testing. Both URLs must point to the same world service. Configure the server’s `ALLOWED_ORIGINS` with the exact hosted client origin.

The protocol is [shared/protocol.md](shared/protocol.md). [Client integration details](docs/CLIENT.md) describe snapshots, deltas, reconnection, storage and the private demo boundary.

## Use the world

- **Observe:** drag or use arrow keys to pan; scroll, pinch or use +/− to zoom; Home or the center button recenters. Select a yellow creature, or use the keyboard-accessible Residents list.
- **Residents:** search/filter; inspect needs, age, relationships, personality, memories, recent decisions, reward updates and wallet opinions. Speech is explicitly template-generated.
- **History:** population and food charts, life/settlement event filters, and CSV resource history. **Browse saved events** reads one page of at most 100 events, oldest first; **Next saved page** follows the server cursor. Retention gaps are explicit. **Show recent events** returns to the bounded live feed. Snapshot recovery clears abandoned events, including rollbacks within the same tick. Lifecycle records remain on the server.
- **Visit:** Connect a wallet, then sign in to the world. Place a visitor and leave food. The deliberately harmful startle experiment requires confirmation and is bounded by the server.
- **Tools:** authorized developers can add food, heal, start fire or trigger storms. Destructive changes need explicit confirmation. Pending intervention IDs survive panel navigation/reload in session storage, scoped to server + world + authenticated wallet; retries with that wallet apply at most once. Switching accounts cannot inherit another actor's retry. Legacy browser requests without an owner remain visible for manual ledger review and cannot be replayed automatically. Tokens remain in memory. The private demo exposes clearly labeled local test tools.
- **World health:** population/life stages, births, deaths and causes, resources, learning, CPU/RAM and tick latency from the service. Unmeasured browser-demo CPU/RAM is labeled as such. Stale views freeze and display connection status and last update.

The demo starts with the configured default seed of 24 and advances the existing engine through 900 ticks before opening, allowing it to build real shelters. It then runs at 4 ticks/s; pause, 1×, 4× and 12× are **local-only** controls. It resets on reload, is private to the tab, and is subject to browser background throttling. The shared server cannot be paused or accelerated by a viewer.

## VPS installation and operations

The [Dockerfile](deploy/Dockerfile), [Docker Compose](deploy/docker-compose.yml), [installation commands](deploy/INSTALL.md), [backup script](deploy/backup.sh) and [restore script](deploy/restore.sh) are supplied. The source installation package is [stratoks-vps-source.tar.gz](docs/recovery/VALIDATION.md). The owner installs these on their own Ubuntu ARM64 VPS; no server access is requested. Target: 2 shared vCPUs, 4 GB RAM, 40 GB SSD. Routine CLI backups briefly stop the service to avoid races with a separate writer; the authenticated in-process backup endpoint can still run online.

Follow `deploy/INSTALL.md` to set DNS, the server hostname, exact allowed origins and **your own** developer wallet allowlist, then run `docker compose up -d --build` from `deploy/`. Check `/health` and `/api/status`, set the client service URLs, and verify a backup/restore before inviting visitors. Keep the data volume across upgrades. Never delete it to recover from an error: that would discard the world.

World snapshots, individual learning, experiences, relationships and lifecycle history persist. The existing migration, checksummed backup and restoration procedures are documented in [server/README.md](server/README.md). Downtime catch-up is capped and non-lethal by default, with births suspended during catch-up. Extinction preserves history; only the authenticated reset endpoint can explicitly start another world. There is intentionally no public reset UI.

The snapshot commits world, RNG/learning state, lifecycle/event history and accepted actor-owned intervention IDs. An HTTP 503 or lost response leaves the exact request retryable with the original actor; even a later retry's authentication/rate-limit error cannot erase that uncertain outcome. See [migration and rollback](server/docs/DURABILITY.md) before upgrading existing data. Explicit `LEARNING=0`/`1` applies on restart while preserving learned state; unset retains the stored policy. Durable intervention and lifecycle ledgers grow; monitor disk and snapshot size and retain offsite backups.

## Checks actually run

See [current validation and six-domain review](docs/recovery/VALIDATION.md), [current raw evidence](docs/recovery/) and [design system](DESIGN.md). Older measurements in `docs/results/` and `docs/VALIDATION.md` are historical.

All four prior client repairs were rerun against the corrected export: landscape viewport overflow, connection notices covering the title, rejected visitor presence shown as success, and learning status during detail loading. The focused production-browser suite passed **22 checks**, including real-service capacity rejection/recovery. The added Phase 1.1 browser suite passed **10 checks** covering actor switches, reloads, legacy retries, real save failure, paginated history, retention gaps, recovery, and real 429/recovery. [Before/final evidence](docs/recovery/) includes the reproduced actor leak and same-tick recovery failure.

- Production build and TypeScript check: passed.
- Server tests: **46/46 passed**, including real SIGKILL write boundaries, event rotation/UTF-8 boundaries, limiter spoofing/recovery, learning restarts, actor idempotency, and offline backup export/restore.
- Client tests: **14/14 passed**, including protocol recovery, actor-owned pending storage and API error handling.
- Chromium integration: **20 checks passed**, including two actual browser clients sharing a real local service; EIP-6963 discovery; viem-generated EIP-191 signature verification; visits; developer actions; lost-response retry; reconnect; explicit reset.
- Rendered interface suite: **9/9 passed**, including seven axe states with zero violations. The pinned `taste@1` probe: **16/16 passed** at 320, 390 and 1440 px. Contrast measurements and screenshots are in the evidence.
- Fresh independent signature generation: **12 valid and 48 invalid cases passed**, using locked viem 2.57.11; inherited ethers fixture cross-checks also passed. Ephemeral test accounts only, no transactions.
- Process deployment smoke: **7/7 passed** for health, allowed origins, SIGTERM/SIGKILL, persistence, learning policy and backup/restore. Docker is unavailable; no ARM64 or emulation result is claimed.
- Earlier **500,000-tick**, population-scaling, WebSocket load and eight-seed learning measurements remain historical. They were not rerun and are **not a capacity promise for the VPS**.

Reproduce the main checks:

```sh
node --test tests/*.test.js
node web/scripts/task.mjs typecheck
node web/scripts/task.mjs test
node web/scripts/task.mjs build
node web/scripts/check-browser.mjs
node web/scripts/check-interface.mjs
node web/scripts/check-revision.mjs /tmp/stratoks-revision-checks
node web/scripts/check-phase11.mjs artifacts/phase-1.1
node web/scripts/check-signatures.mjs artifacts/phase-1.1/signatures.json
node deploy/check-process.mjs 18790 artifacts/phase-1.1/process-checks.json
```

Browser scripts require Playwright’s Chromium runtime. Install it through the isolated frontend’s `node_modules/.bin/playwright install chromium`. `PLAYWRIGHT_BROWSERS_PATH` can point to a temporary directory; set it consistently for installation and checks. Run scripts sequentially; `check-interface.mjs` accepts an optional port if 4190 is occupied. This worker's browser fallback/version, initial failed checks and repairs are recorded in validation. `check-browser.mjs --capture-share` explicitly regenerates the share image; rebuild afterwards. The pinned taste probe is removed after submission; its exact current output is retained in `artifacts/phase-1.1/taste.json`.

After IMD supplies this release's CID and HTTPS gateway, run `node web/scripts/verify-publication.mjs <https-release-base-url/> artifacts/phase-1.1/publication-verified.json`. It checks every served byte against local `dist/`, HTTPS redirects and script MIME types, and rejects stale exports or gateway challenge pages. This check has not passed for a public release in this task.

## Honest remaining boundaries

- **Publication is incomplete:** ENS HTTPS failed with `ERR_SSL_PROTOCOL_ERROR`; both tested gateways for the historical CID returned HTTP 403 challenge pages. No corrected-release CID/URL/commit has been assigned or verified by this worker. The machine identity required by the available daemon is outside permitted task access. No backend deployment is implied by the static export.
- **Not run:** Docker/Compose (`docker: command not found`), native/emulated ARM64, the owner’s VPS, Caddy/TLS end-to-end, physical phones, actual wallet extensions/apps/passkeys, screen readers, native zoom, RTL/localization, or an independent reviewer. WebKit launch was attempted but its executable is absent from this task's temporary browser installation. Chromium mobile emulation is not native Safari or a real device.
- **Smart-wallet limitation:** EIP-6963 browser wallets, four mobile wallet-browser links and the Coinbase Smart Wallet connector are supplied. The inherited server protocol verifies EIP-191 account signatures only. Smart-account EIP-1271/EIP-6492 authentication is not implemented; the interface says so and never treats a connected smart account as authenticated. There is no chain-switch requirement for these signature-only accounts.
- The simulation uses lightweight contextual learning and bounded memories, not an LLM or consciousness model. Nearest-creature scans scale superlinearly. Long-run starvation remains a tuning concern; production art, public extinction policy, payments and future phases are unfinished by design.

[Asset licenses and attribution](docs/ASSETS.md) cover all original art, bundled font, wallet marks and design guidance.
